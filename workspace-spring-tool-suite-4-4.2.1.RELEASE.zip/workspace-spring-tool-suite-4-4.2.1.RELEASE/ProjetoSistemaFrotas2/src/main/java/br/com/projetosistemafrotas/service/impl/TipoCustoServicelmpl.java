package br.com.projetosistemafrotas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.TipoCusto;
import br.com.projetosistemafrotas.repository.TipoCustoRepository;
import br.com.projetosistemafrotas.service.TipoCustoService;

@Service
public class TipoCustoServicelmpl implements TipoCustoService {

	@Autowired
	private TipoCustoRepository repository;
	
	@Override
	public List<TipoCusto> getAll() {
		return repository.findAll();
	}

	@Override
	public void save(TipoCusto tipoCusto) {
		repository.save(tipoCusto);
	}

	@Override
	public void delete(TipoCusto tipoCusto) {
		// TODO Auto-generated method stub
		repository.delete(tipoCusto);
	}

}
