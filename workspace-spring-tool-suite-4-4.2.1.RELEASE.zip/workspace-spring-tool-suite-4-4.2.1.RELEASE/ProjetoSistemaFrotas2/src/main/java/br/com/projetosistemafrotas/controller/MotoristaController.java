package br.com.projetosistemafrotas.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projetosistemafrotas.model.Motorista;
import br.com.projetosistemafrotas.service.MotoristaService;

@Controller
@RequestMapping("/motorista")
public class MotoristaController {
	
	@Autowired
	private MotoristaService motoristaService;
	
	@GetMapping()
	public ModelAndView index() {
		List<Motorista> lista = motoristaService.getAll();
		
		return new ModelAndView("motorista/index","motoristas",lista);
		
	}
	
	@GetMapping("/novo")
	public ModelAndView createForm(@ModelAttribute Motorista motorista) {
		return new ModelAndView("motorista/form");	
	}
	@PostMapping(params="form")
	public ModelAndView save(@Valid Motorista motorista) 
	{
		motoristaService.save(motorista);
		return new ModelAndView("redirect:/motorista");
	}
	@GetMapping(value="/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Motorista motorista) 
	{
	return new ModelAndView("motorista/form","motorista",motorista);
	}
	
	@GetMapping(value="/delete/{id}")
	public ModelAndView delete(@PathVariable("id") Motorista motorista) 
	{
		motoristaService.delete(motorista);
		return new ModelAndView("redirect:/motorista");
	}
	
}