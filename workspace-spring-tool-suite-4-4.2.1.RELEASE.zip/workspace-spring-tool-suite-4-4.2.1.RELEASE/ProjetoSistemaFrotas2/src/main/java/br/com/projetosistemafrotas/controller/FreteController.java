package br.com.projetosistemafrotas.controller;


import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projetosistemafrotas.model.Cliente;
import br.com.projetosistemafrotas.model.Contrato;
import br.com.projetosistemafrotas.model.Custo;
import br.com.projetosistemafrotas.model.Frete;
import br.com.projetosistemafrotas.model.Motorista;
import br.com.projetosistemafrotas.model.Veiculo;
import br.com.projetosistemafrotas.repository.ClienteRepository;
import br.com.projetosistemafrotas.repository.ContratoRepository;
import br.com.projetosistemafrotas.repository.MotoristaRepository;
import br.com.projetosistemafrotas.repository.VeiculoRepository;
import br.com.projetosistemafrotas.service.FreteService;

@Controller
@RequestMapping("/frete")
public class FreteController {
	
	@Autowired
	private FreteService freteService;
	
	@Autowired
	private VeiculoRepository veiculoRepository;
	@Autowired
	private MotoristaRepository motoristaRepository;
	@Autowired
	private ContratoRepository contratoRepository;
	@Autowired
	private ClienteRepository clienteRepository;
	
	@GetMapping()
	public ModelAndView index() {
		List<Frete> lista = freteService.getAll();
		return new ModelAndView("frete/index","fretes",lista);
	}
	@GetMapping("/report")
	public ModelAndView report() {
		List<Frete> lista = freteService.getAll();		
		return new ModelAndView("frete/report","fretes",lista);
	}
	@GetMapping("/novo")
	public ModelAndView createForm(@ModelAttribute Frete frete) {
		List<Cliente> listaCliente = clienteRepository.findAll();
		List<Motorista> listaMotorista = motoristaRepository.findAll();
		List<Veiculo> listaVeiculos = veiculoRepository.findAll();
		List<Contrato> listaContrato = contratoRepository.findAll();
	    HashMap<String, Object> dados = new HashMap<String, Object>();
	    dados.put("frete", frete);
	    dados.put("listaCliente",listaCliente);
	    dados.put("listaMotorista",listaMotorista);
	    dados.put("listaVeiculos",listaVeiculos);
	    dados.put("listaContrato",listaContrato);
	    return new ModelAndView("frete/form",dados);
	}
	@PostMapping(params="form")
	public ModelAndView save(@Valid Frete frete, BindingResult result){
		if(result.hasErrors()) {
			List<Cliente> listaCliente = clienteRepository.findAll();
			List<Motorista> listaMotorista = motoristaRepository.findAll();
			List<Veiculo> listaVeiculos = veiculoRepository.findAll();
			List<Contrato> listaContrato = contratoRepository.findAll();
		    HashMap<String, Object> dados = new HashMap<String, Object>();
		    dados.put("listaCliente",listaCliente);
		    dados.put("listaMotorista",listaMotorista);
		    dados.put("listaVeiculos",listaVeiculos);
		    dados.put("listaContrato",listaContrato);
			return new ModelAndView("frete/form", dados);
		}
		freteService.save(frete);
		return new ModelAndView("redirect:/frete");
	}
	@GetMapping(value="/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Frete frete) 
	{
		List<Cliente> listaCliente = clienteRepository.findAll();
		List<Motorista> listaMotorista = motoristaRepository.findAll();
		List<Veiculo> listaVeiculos = veiculoRepository.findAll();
		List<Contrato> listaContrato = contratoRepository.findAll();
	    HashMap<String, Object> dados = new HashMap<String, Object>();
	    dados.put("frete", frete);
	    dados.put("listaCliente",listaCliente);
	    dados.put("listaMotorista",listaMotorista);
	    dados.put("listaVeiculos",listaVeiculos);
	    dados.put("listaContrato",listaContrato);
	    return new ModelAndView("frete/form",dados);
	}
	
	@GetMapping(value="/delete/{id}")
	public ModelAndView delete(@PathVariable("id") Frete frete) 
	{
	freteService.delete(frete);
	return new ModelAndView("redirect:/frete");
	}
	
}