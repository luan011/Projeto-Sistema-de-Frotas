package br.com.projetosistemafrotas.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
public class Cliente {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	@NotNull()
	@NotEmpty(message="O campo Nome não pode estar em branco")
	private String nome;
	@Temporal(value=TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dataNascimento;
	@NotNull()
	@NotEmpty(message="O campo CPF não pode estar em branco")
	private String CPF;
	@NotNull()
	@NotEmpty(message="O campo Telefone não pode estar em branco")
	private String telefone;
	@NotNull()
	@NotEmpty(message="O campo Estado não pode estar em branco")
	private String estado;
	@NotNull()
	@NotEmpty(message="O campo Cidade não pode estar em branco")
	private String cidade;
	@NotNull()
	@NotEmpty(message="O campo Endereço não pode estar em branco")
	private String endereco;
	@NotNull()
	@NotEmpty(message="O campo RG não pode estar em branco")
	private String RG;
	@Email(message = "O Email não é válido")
	private String email;
	
	public String getRG() {
		return RG;
	}
	public String getEmail() {
		return email;
	}
	public void setRG(String rG) {
		RG = rG;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
}
