package br.com.projetosistemafrotas.service;


import java.util.List;

import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.ManutencaoVeiculo;

@Service
public interface ManutencaoVeiculoService {
	List<ManutencaoVeiculo> getAll();
	void save(ManutencaoVeiculo manutencaoVeiculo);
	void delete(ManutencaoVeiculo manutencaoVeiculo);
}
