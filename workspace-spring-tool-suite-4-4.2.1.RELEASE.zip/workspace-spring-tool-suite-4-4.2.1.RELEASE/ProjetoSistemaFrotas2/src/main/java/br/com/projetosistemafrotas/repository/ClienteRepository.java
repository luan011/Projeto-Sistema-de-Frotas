package br.com.projetosistemafrotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.projetosistemafrotas.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long>{
	Cliente findByNome(String nome);
}
