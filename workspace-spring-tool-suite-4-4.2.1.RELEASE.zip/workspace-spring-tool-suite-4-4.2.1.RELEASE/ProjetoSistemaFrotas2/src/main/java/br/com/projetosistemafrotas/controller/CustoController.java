package br.com.projetosistemafrotas.controller;


import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projetosistemafrotas.model.Cliente;
import br.com.projetosistemafrotas.model.Custo;
import br.com.projetosistemafrotas.model.TipoCusto;
import br.com.projetosistemafrotas.repository.CustoRepository;
import br.com.projetosistemafrotas.repository.TipoCustoRepository;
import br.com.projetosistemafrotas.service.CustoService;

@Controller
@RequestMapping("/custo")
public class CustoController {
	
	@Autowired
	private CustoService custoService;
	
	@Autowired
	private TipoCustoRepository tipoCustoRepository;
	
	@GetMapping()
	public ModelAndView index() {
		List<Custo> lista = custoService.getAll();		
		return new ModelAndView("custo/index","custos",lista);
	}
	@GetMapping("/report")
	public ModelAndView report() {
		List<Custo> lista = custoService.getAll();		
		return new ModelAndView("custo/report","custos",lista);
	}

	@GetMapping("/novo")
	public ModelAndView createForm(@ModelAttribute Custo custo) {
		List<TipoCusto> listaCustos = tipoCustoRepository.findAll();
        return new ModelAndView("custo/form","listaCustos",listaCustos);
	}
	
	@PostMapping(params="form")
	public ModelAndView save(@Valid Custo custo, BindingResult result){
		if(result.hasErrors()) {
			List<TipoCusto> listaCustos = tipoCustoRepository.findAll();
			HashMap<String, Object> dados = new HashMap<>();
			dados.put("listaCustos",listaCustos);
			dados.put("custo",custo);
			return new ModelAndView("custo/form", dados);
		}
		custoService.save(custo);
		return new ModelAndView("redirect:/custo");
	}
		
	@GetMapping(value="/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Custo custo){
		List<TipoCusto> listaCustos = tipoCustoRepository.findAll();
	    HashMap<String, Object> dados = new HashMap<String, Object>();
	    dados.put("custo", custo);
	    dados.put("listaCustos",listaCustos);
	    return new ModelAndView("custo/form", dados);    
	}
	
	@GetMapping(value="/delete/{id}")
	public ModelAndView delete(@PathVariable("id") Custo custo) {
		custoService.delete(custo);
		return new ModelAndView("redirect:/custo");
	}
	
}