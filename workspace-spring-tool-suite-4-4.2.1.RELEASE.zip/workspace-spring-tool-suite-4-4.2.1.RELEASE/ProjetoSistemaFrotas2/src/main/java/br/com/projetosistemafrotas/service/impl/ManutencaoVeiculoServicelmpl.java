package br.com.projetosistemafrotas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.ManutencaoVeiculo;
import br.com.projetosistemafrotas.repository.ManutencaoVeiculoRepository;
import br.com.projetosistemafrotas.service.ManutencaoVeiculoService;

@Service
public class ManutencaoVeiculoServicelmpl implements ManutencaoVeiculoService {

	@Autowired
	private ManutencaoVeiculoRepository repository;
	
	@Override
	public List<ManutencaoVeiculo> getAll() {
		return repository.findAll();
	}

	@Override
	public void save(ManutencaoVeiculo manutencaoVeiculo) {
		repository.save(manutencaoVeiculo);
	}

	@Override
	public void delete(ManutencaoVeiculo manutencaoVeiculo) {
		// TODO Auto-generated method stub
		repository.delete(manutencaoVeiculo);
	}

}
