package br.com.projetosistemafrotas.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.PositiveOrZero;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class ManutencaoVeiculo {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	@PositiveOrZero(message="O campo Custo de Manutenção não pode ser negativo")
	private double custoManutencao;
	@Temporal(value=TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dataManutencao;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public double getCustoManutencao() {
		return custoManutencao;
	}
	public void setCustoManutencao(double custoManutencao) {
		this.custoManutencao = custoManutencao;
	}
	public Date getDataManutencao() {
		return dataManutencao;
	}
	public void setDataManutencao(Date dataManutencao) {
		this.dataManutencao = dataManutencao;
	}

	
}
