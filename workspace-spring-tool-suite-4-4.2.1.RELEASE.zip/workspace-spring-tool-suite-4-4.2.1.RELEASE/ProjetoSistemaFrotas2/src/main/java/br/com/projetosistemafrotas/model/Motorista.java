package br.com.projetosistemafrotas.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Motorista {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id ;
	@NotNull()
	@NotEmpty(message="O campo Nome não pode estar em branco")
	private String nome;
	@NotNull()
	@NotEmpty(message="O campo Endereço não pode estar em branco")
	private String endereco;
	@NotNull()
	@NotEmpty(message="O campo CNH não pode estar em branco")
	private String CNH;
	@NotNull()
	@NotEmpty(message="O campo CPF não pode estar em branco")
	private String CPF;
	@NotNull()
	@NotEmpty(message="O campo RG não pode estar em branco")
	private String RG;
	@NotNull()
	@NotEmpty(message="O campo Telefone não pode estar em branco")
	private String telefone;
	@Email(message = "O Email não é válido")
	private String email;
	@Temporal(value=TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dataNascimento;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getCNH() {
		return CNH;
	}
	public void setCNH(String cNH) {
		CNH = cNH;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public Date getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getCPF() {
		return CPF;
	}
	public String getRG() {
		return RG;
	}
	public String getEmail() {
		return email;
	}
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	public void setRG(String rG) {
		RG = rG;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
