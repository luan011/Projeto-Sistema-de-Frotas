package br.com.projetosistemafrotas.service;

import java.util.List;

import org.springframework.stereotype.Service;
import br.com.projetosistemafrotas.model.Frete;;

@Service
public interface FreteService {
	List<Frete> getAll();
	void save(Frete frete);
	void delete(Frete frete);
}