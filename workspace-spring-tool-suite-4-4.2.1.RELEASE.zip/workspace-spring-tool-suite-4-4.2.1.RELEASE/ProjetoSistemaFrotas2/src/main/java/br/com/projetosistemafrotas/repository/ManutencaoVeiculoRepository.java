package br.com.projetosistemafrotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.projetosistemafrotas.model.ManutencaoVeiculo;

public interface ManutencaoVeiculoRepository extends JpaRepository<ManutencaoVeiculo, Long>{
	ManutencaoVeiculo findByid(long id);

}
