package br.com.projetosistemafrotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.projetosistemafrotas.model.TipoCusto;

public interface TipoCustoRepository extends JpaRepository<TipoCusto, Long>{
	TipoCusto findById(long id);
}
