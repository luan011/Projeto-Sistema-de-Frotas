package br.com.projetosistemafrotas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.Custo;
import br.com.projetosistemafrotas.repository.CustoRepository;
import br.com.projetosistemafrotas.service.CustoService;

@Service
public class CustoServicelmpl implements CustoService {

	
	@Autowired
	private CustoRepository repository;
	
	@Override
	public List<Custo> getAll() {
		return repository.findAll();
	}

	@Override
	public void save(Custo custo) {
		repository.save(custo);
	}

	@Override
	public void delete(Custo custo) {
		repository.delete(custo);
	}

}