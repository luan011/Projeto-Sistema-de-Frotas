package br.com.projetosistemafrotas.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projetosistemafrotas.model.TipoCusto;
import br.com.projetosistemafrotas.service.TipoCustoService;

@Controller
@RequestMapping("/tipoCusto")
public class TipoCustoController {
	
	@Autowired
	private TipoCustoService tipoCustoService;
	
	@GetMapping()
	public ModelAndView index() {
		List<TipoCusto> lista = tipoCustoService.getAll();
		
		return new ModelAndView("tipoCusto/index","tipoCustos",lista);
		
	}
	
	@GetMapping("/novo")
	public ModelAndView createForm(@ModelAttribute TipoCusto tipoCusto) {
		return new ModelAndView("tipoCusto/form");	
	}
	@PostMapping(params="form")
	public ModelAndView save(@Valid TipoCusto tipoCusto, BindingResult result) 
	{
		if(result.hasErrors()) {
			return new ModelAndView("tipoCusto/form");
		}
		tipoCustoService.save(tipoCusto);
		return new ModelAndView("redirect:/tipoCusto");
	}
	@GetMapping(value="/edit/{id}")
	public ModelAndView edit(@PathVariable("id") TipoCusto tipoCusto) 
	{
	return new ModelAndView("tipoCusto/form","tipoCusto",tipoCusto);
	}
	
	@GetMapping(value="/delete/{id}")
	public ModelAndView delete(@PathVariable("id") TipoCusto tipoCusto) 
	{
	tipoCustoService.delete(tipoCusto);
	return new ModelAndView("redirect:/tipoCusto");
	}
	
}