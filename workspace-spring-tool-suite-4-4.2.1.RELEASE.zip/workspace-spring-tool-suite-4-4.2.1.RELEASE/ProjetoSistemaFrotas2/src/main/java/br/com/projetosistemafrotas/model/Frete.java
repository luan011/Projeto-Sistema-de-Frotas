package br.com.projetosistemafrotas.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Frete {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id ;
	@Column(length=800)
	private String origem;
	private String destino;
	private double valor;
	private int kilometragem;
	@Temporal(value=TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dataPedido; 
	@Temporal(value=TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dataEntrega;
	private int totalDias;
	@ManyToOne(cascade= {CascadeType.MERGE, CascadeType.REFRESH}, optional=false)//muitos pra 1(* --> 1)
	private Veiculo veiculo;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="id_frete")
	private List <Custo> listaCustos = new ArrayList<Custo>();
	@ManyToOne(cascade= {CascadeType.MERGE, CascadeType.REFRESH}, optional=false)//muitos pra 1(* --> 1)
	private Motorista motorista;
	@ManyToOne(cascade= {CascadeType.MERGE, CascadeType.REFRESH}, optional=false)//muitos pra 1(* --> 1)
	private Cliente cliente;
	@ManyToOne(cascade= {CascadeType.MERGE, CascadeType.REFRESH}, optional=false)//muitos pra 1(* --> 1)
	private Contrato contrato;
	
	

	public List<Custo> getListaCustos() {
		return listaCustos;
	}
	public void setListaCustos(List<Custo> listaCustos) {
		this.listaCustos = listaCustos;
	}
	public Motorista getMotorista() {
		return motorista;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public Contrato getContrato() {
		return contrato;
	}
	public void setMotorista(Motorista motorista) {
		this.motorista = motorista;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public void setContrato(Contrato contrato) {
		this.contrato = contrato;
	}
	public Veiculo getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(Veiculo veiculo) {
		this.veiculo = veiculo;
	}
	public long getId() {
		return id;
	}
	public String getOrigem() {
		return origem;
	}
	public String getDestino() {
		return destino;
	}
	public double getValor() {
		return valor;
	}
	public int getKilometragem() {
		return kilometragem;
	}
	public Date getDataPedido() {
		return dataPedido;
	}
	public Date getDataEntrega() {
		return dataEntrega;
	}
	public int getTotalDias() {
		return totalDias;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setOrigem(String origem) {
		this.origem = origem;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public void setKilometragem(int kilometragem) {
		this.kilometragem = kilometragem;
	}
	public void setDataPedido(Date dataPedido) {
		this.dataPedido = dataPedido;
	}
	public void setDataEntrega(Date dataEntrega) {
		this.dataEntrega = dataEntrega;
	}
	public void setTotalDias(int totalDias) {
		this.totalDias = totalDias;
	}

}
