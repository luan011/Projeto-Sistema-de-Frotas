package br.com.projetosistemafrotas.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
public class TipoCusto {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id ;
	@NotNull()
	@NotEmpty(message="O campo Nome não pode estar em branco")
	private String nomeTipo;
	
	public String getNomeTipo() {
		return nomeTipo;
	}
	public void setNomeTipo(String nomeTipo) {
		this.nomeTipo = nomeTipo;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

}
