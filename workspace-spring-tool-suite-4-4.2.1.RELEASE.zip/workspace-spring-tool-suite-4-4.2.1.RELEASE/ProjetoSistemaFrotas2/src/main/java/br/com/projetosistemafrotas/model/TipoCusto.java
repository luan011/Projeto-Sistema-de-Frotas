package br.com.projetosistemafrotas.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class TipoCusto {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id ;
	private String nomeTipo;
	
	public String getNomeTipo() {
		return nomeTipo;
	}
	public void setNomeTipo(String nomeTipo) {
		this.nomeTipo = nomeTipo;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	/*
	private double pedagio;
	private double custoCombustivel;

	public double getPedagio() {
		return pedagio;
	}
	public double getCustoCombustivel() {
		return custoCombustivel;
	}
	public void setPedagio(double pedagio) {
		this.pedagio = pedagio;
	}
	public void setCustoCombustivel(double custoCombustivel) {
		this.custoCombustivel = custoCombustivel;
	}
*/

}
