package br.com.projetosistemafrotas.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Contrato {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	private double valor;
	@Column(length=800)
	private String origem;
	private String destino;
	private String empresaOrigem;
	private String empresaDestino;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getOrigem() {
		return origem;
	}
	public String getDestino() {
		return destino;
	}
	public String getEmpresaOrigem() {
		return empresaOrigem;
	}
	public String getEmpresaDestino() {
		return empresaDestino;
	}
	public void setOrigem(String origem) {
		this.origem = origem;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public void setEmpresaOrigem(String empresaOrigem) {
		this.empresaOrigem = empresaOrigem;
	}
	public void setEmpresaDestino(String empresaDestino) {
		this.empresaDestino = empresaDestino;
	}
	
}
