package br.com.projetosistemafrotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.projetosistemafrotas.model.Custo;
import br.com.projetosistemafrotas.model.TipoCusto;;

public interface CustoRepository extends JpaRepository<Custo, Long>{
	Custo findByTipoCusto(TipoCusto tipoCusto);
}
