package br.com.projetosistemafrotas.controller;


import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projetosistemafrotas.model.ManutencaoVeiculo;
import br.com.projetosistemafrotas.model.Veiculo;
import br.com.projetosistemafrotas.repository.ManutencaoVeiculoRepository;
import br.com.projetosistemafrotas.service.VeiculoService;

@Controller
@RequestMapping("/veiculo")
public class VeiculoController {
	
	@Autowired
	private VeiculoService veiculoService;
	
	@Autowired
	private ManutencaoVeiculoRepository manutencaoVeiculoRepository;
	
	@GetMapping()
	public ModelAndView index() {
		List<Veiculo> lista = veiculoService.getAll();
		
		return new ModelAndView("veiculo/index","veiculos",lista);
		
	}
	
	@GetMapping("/novo")
	public ModelAndView createForm(@ModelAttribute Veiculo veiculo) {
		List<ManutencaoVeiculo> listaManutencao = manutencaoVeiculoRepository.findAll();
        return new ModelAndView("veiculo/form","listaManutencao",listaManutencao);
	}
	@PostMapping(params="form")
	public ModelAndView save(@Valid Veiculo veiculo, BindingResult result) 
	{
		if(result.hasErrors()) {
			return new ModelAndView("veiculo/form");
		}
		veiculoService.save(veiculo);
		return new ModelAndView("redirect:/veiculo");
	}
	@GetMapping(value="/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Veiculo veiculo) {
		List<ManutencaoVeiculo> listaManutencao = manutencaoVeiculoRepository.findAll();
	    HashMap<String, Object> dados = new HashMap<String, Object>();
	    dados.put("veiculo", veiculo);
	    dados.put("listaManutencao",listaManutencao);
	    return new ModelAndView("veiculo/form", dados); 
	}
	
	@GetMapping(value="/delete/{id}")
	public ModelAndView delete(@PathVariable("id") Veiculo veiculo) {
		veiculoService.delete(veiculo);
		return new ModelAndView("redirect:/veiculo");
	}
	
	/*
	 	<div class="form-group">
                        <label for="slcManutencaoVeiculo">Custo da Manutenção</label>
                        <select class="form-control" id="slcsexo" th:field="*{manutencaoVeiculo}">
                        <option th:each="ummanutencaoVeiculo : ${listaManutencaos}" th:value="${ummanutencaoVeiculo.id}" th:value="${ummanutencaoVeiculo.custoManutencao}"></option>
                        </select>
                    </div>
                    */
	
}