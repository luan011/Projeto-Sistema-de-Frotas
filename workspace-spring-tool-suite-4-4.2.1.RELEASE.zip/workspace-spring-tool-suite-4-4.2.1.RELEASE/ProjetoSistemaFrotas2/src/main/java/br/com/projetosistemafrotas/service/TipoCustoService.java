package br.com.projetosistemafrotas.service;


import java.util.List;

import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.TipoCusto;

@Service
public interface TipoCustoService {
	List<TipoCusto> getAll();
	void save(TipoCusto tipoCusto);
	void delete(TipoCusto tipoCusto);
}
