package br.com.projetosistemafrotas.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.Contrato;

@Service
public interface ContratoService {
	List<Contrato> getAll();
	void save(Contrato contrato);
	void delete(Contrato contrato);
}
