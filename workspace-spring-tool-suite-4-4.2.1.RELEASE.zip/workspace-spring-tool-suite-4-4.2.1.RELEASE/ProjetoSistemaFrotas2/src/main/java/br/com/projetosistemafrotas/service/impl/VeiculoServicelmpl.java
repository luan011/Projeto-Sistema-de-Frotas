package br.com.projetosistemafrotas.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.Veiculo;
import br.com.projetosistemafrotas.repository.VeiculoRepository;
import br.com.projetosistemafrotas.service.VeiculoService;

@Service
public class VeiculoServicelmpl implements VeiculoService {

		@Autowired
		private VeiculoRepository repository;
		
		@Override
		public List<Veiculo> getAll() {
			return repository.findAll();
		}

		@Override
		public void save(Veiculo veiculo) {
			repository.save(veiculo);
			
		}

		@Override
		public void delete(Veiculo veiculo) {
			// TODO Auto-generated method stub
			repository.delete(veiculo);
		}

}
