package br.com.projetosistemafrotas.service;

import java.util.List;

import org.springframework.stereotype.Service;
import br.com.projetosistemafrotas.model.Custo;;

@Service
public interface CustoService {
	List<Custo> getAll();
	void save(Custo custo);
	void delete(Custo custo);
}
