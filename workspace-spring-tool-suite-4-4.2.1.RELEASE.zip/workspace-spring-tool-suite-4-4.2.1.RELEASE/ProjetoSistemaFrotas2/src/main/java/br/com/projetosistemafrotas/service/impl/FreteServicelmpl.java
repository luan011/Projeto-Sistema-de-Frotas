package br.com.projetosistemafrotas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.Frete;
import br.com.projetosistemafrotas.repository.FreteRepository;
import br.com.projetosistemafrotas.service.FreteService;

@Service
public class FreteServicelmpl implements FreteService {

	
	@Autowired
	private FreteRepository repository;
	
	@Override
	public List<Frete> getAll() {
		return repository.findAll();
	}

	@Override
	public void save(Frete frete) {
		repository.save(frete);
	}

	@Override
	public void delete(Frete frete) {
		repository.delete(frete);
	}

}