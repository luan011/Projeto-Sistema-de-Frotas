package br.com.projetosistemafrotas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.Motorista;
import br.com.projetosistemafrotas.repository.MotoristaRepository;
import br.com.projetosistemafrotas.service.MotoristaService;

@Service
public class MotoristaServicelmpl implements MotoristaService {

	
	@Autowired
	private MotoristaRepository repository;
	
	@Override
	public List<Motorista> getAll() {
		return repository.findAll();
	}

	@Override
	public void save(Motorista motorista) {
		repository.save(motorista);
	}

	@Override
	public void delete(Motorista motorista) {
		repository.delete(motorista);
	}

}
