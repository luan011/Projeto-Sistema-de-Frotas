package br.com.projetosistemafrotas.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue; 
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.PositiveOrZero;;

@Entity
public class Custo {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id ;
	@PositiveOrZero(message="O campo Custo Total não pode ser negativo")
	//@Pattern(regexp = "[0-9]+", message="O campo Custo Total não pode ser negativo")
	private double custoTotal;
	@ManyToOne(cascade= {CascadeType.MERGE, CascadeType.REFRESH}, optional=false)//muitos pra 1(* --> 1)
	private TipoCusto tipoCusto = new TipoCusto();
	
	public long getId() {
		return id;
	}
	public TipoCusto getTipoCusto() {
		return tipoCusto;
	}
	public void setTipoCusto(TipoCusto tipoCusto) {
		this.tipoCusto = tipoCusto;
	}
	public double getCustoTotal() {
		return custoTotal;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setCustoTotal(double custoTotal) {
		this.custoTotal = custoTotal;
	}
	
}
