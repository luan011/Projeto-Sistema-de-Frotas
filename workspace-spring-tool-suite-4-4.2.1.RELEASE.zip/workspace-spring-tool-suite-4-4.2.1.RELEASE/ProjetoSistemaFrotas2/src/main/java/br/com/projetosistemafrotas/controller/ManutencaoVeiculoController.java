package br.com.projetosistemafrotas.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.projetosistemafrotas.model.ManutencaoVeiculo;
import br.com.projetosistemafrotas.service.ManutencaoVeiculoService;

@Controller
@RequestMapping("/manutencaoVeiculo")
public class ManutencaoVeiculoController {
	
	@Autowired
	private ManutencaoVeiculoService manutencaoVeiculoService;
	
	@GetMapping()
	public ModelAndView index() {
		List<ManutencaoVeiculo> lista = manutencaoVeiculoService.getAll();
		
		return new ModelAndView("manutencaoVeiculo/index","manutencaoVeiculos",lista);
		
	}
	
	@GetMapping("/novo")
	public ModelAndView createForm(@ModelAttribute ManutencaoVeiculo manutencaoVeiculo) {
		return new ModelAndView("manutencaoVeiculo/form");	
	}
	@PostMapping(params="form")
	public ModelAndView save(@Valid ManutencaoVeiculo manutencaoVeiculo) 
	{
		manutencaoVeiculoService.save(manutencaoVeiculo);
		return new ModelAndView("redirect:/manutencaoVeiculo");
	}
	@GetMapping(value="/edit/{id}")
	public ModelAndView edit(@PathVariable("id") ManutencaoVeiculo manutencaoVeiculo) 
	{
	return new ModelAndView("manutencaoVeiculo/form","manutencaoVeiculo",manutencaoVeiculo);
	}
	
	@GetMapping(value="/delete/{id}")
	public ModelAndView delete(@PathVariable("id") ManutencaoVeiculo manutencaoVeiculo) 
	{
	manutencaoVeiculoService.delete(manutencaoVeiculo);
	return new ModelAndView("redirect:/manutencaoVeiculo");
	}
	
}