package br.com.projetosistemafrotas.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.Motorista;

@Service
public interface MotoristaService {
	List<Motorista> getAll();
	void save(Motorista motorista);
	void delete(Motorista motorista);
}
