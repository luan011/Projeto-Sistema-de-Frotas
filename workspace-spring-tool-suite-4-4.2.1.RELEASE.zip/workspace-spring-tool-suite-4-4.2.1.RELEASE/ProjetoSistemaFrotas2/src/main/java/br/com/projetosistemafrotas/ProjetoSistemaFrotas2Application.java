package br.com.projetosistemafrotas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSistemaFrotas2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSistemaFrotas2Application.class, args);
	}

}
