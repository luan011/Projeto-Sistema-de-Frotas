package br.com.projetosistemafrotas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projetosistemafrotas.model.Contrato;
import br.com.projetosistemafrotas.repository.ContratoRepository;
import br.com.projetosistemafrotas.service.ContratoService;

@Service
public class ContratoServicelmpl implements ContratoService {

	@Autowired
	private ContratoRepository repository;
	
	@Override
	public List<Contrato> getAll() {
		return repository.findAll();
	}

	@Override
	public void save(Contrato contrato) {
		repository.save(contrato);
	}

	@Override
	public void delete(Contrato contrato) {
		repository.delete(contrato);
	}

}
