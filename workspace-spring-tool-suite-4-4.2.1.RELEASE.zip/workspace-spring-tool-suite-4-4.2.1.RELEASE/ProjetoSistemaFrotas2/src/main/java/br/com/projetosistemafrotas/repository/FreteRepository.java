package br.com.projetosistemafrotas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.projetosistemafrotas.model.Frete;

public interface FreteRepository extends JpaRepository<Frete, Long>{
	Frete findById(long id);
}
