package br.com.projetosistemafrotas.service;

import java.util.List;

import org.springframework.stereotype.Service;
import br.com.projetosistemafrotas.model.Veiculo;

@Service
public interface VeiculoService {
	List<Veiculo> getAll();
	void save(Veiculo veiculo);
	void delete(Veiculo veiculo);
}
