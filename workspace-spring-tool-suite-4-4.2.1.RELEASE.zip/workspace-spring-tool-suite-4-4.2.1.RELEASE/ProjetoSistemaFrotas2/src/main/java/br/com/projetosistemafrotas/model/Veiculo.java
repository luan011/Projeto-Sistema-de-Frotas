package br.com.projetosistemafrotas.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Veiculo {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id ;
	@Column(length=800)
	private String placa;
	private String modelo;
	private String cor;
	private int ano;
	private double cargaMaximaPermitida;
	private double kilometros;
	private double nivelCombustivel;
	private int eixos;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="id_veiculo")
	private List <ManutencaoVeiculo> listaCustos = new ArrayList<ManutencaoVeiculo>();

	public List<ManutencaoVeiculo> getListaCustos() {
		return listaCustos;
	}
	public void setListaCustos(List<ManutencaoVeiculo> listaCustos) {
		this.listaCustos = listaCustos;
	}
	public long getId() {
		return id;
	}
	public String getPlaca() {
		return placa;
	}
	public String getModelo() {
		return modelo;
	}
	public int getAno() {
		return ano;
	}
	public double getCargaMaximaPermitida() {
		return cargaMaximaPermitida;
	}
	public double getKilometros() {
		return kilometros;
	}
	public double getNivelCombustivel() {
		return nivelCombustivel;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public void setCargaMaximaPermitida(double cargaMaximaPermitida) {
		this.cargaMaximaPermitida = cargaMaximaPermitida;
	}
	public void setKilometros(double kilometros) {
		this.kilometros = kilometros;
	}
	public void setNivelCombustivel(double nivelCombustivel) {
		this.nivelCombustivel = nivelCombustivel;
	}
	public String getCor() {
		return cor;
	}
	public int getEixos() {
		return eixos;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public void setEixos(int eixos) {
		this.eixos = eixos;
	}
	
}
