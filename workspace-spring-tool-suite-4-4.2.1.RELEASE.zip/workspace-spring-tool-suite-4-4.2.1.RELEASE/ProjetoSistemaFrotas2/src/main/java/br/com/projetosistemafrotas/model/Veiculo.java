package br.com.projetosistemafrotas.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

@Entity
public class Veiculo {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id ;
	@NotNull()
	@NotEmpty(message="O campo Placa não pode estar em branco")	
	private String placa;
	@NotNull()
	@NotEmpty(message="O campo Modelo não pode estar em branco")	
	private String modelo;
	@NotNull()
	@NotEmpty(message="O campo Cor não pode estar em branco")	
	private String cor;
	@Min(value = 1970, message = "O valor não é válido")
    @Max(value = 2050, message = "O valor não é válido")
	private int ano;
	@PositiveOrZero(message="O campo Custo de Manutenção não pode ser negativo")
	private double cargaMaximaPermitida;
	@PositiveOrZero(message="O campo Custo de Manutenção não pode ser negativo")
	private double kilometros;
	@PositiveOrZero(message="O campo Custo de Manutenção não pode ser negativo")
	private double nivelCombustivel;
	@Min(value = 0, message = "O valor não é válido")
    @Max(value = 3, message = "O valor não é válido")
	private int eixos;	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="id_veiculo")
	private List <ManutencaoVeiculo> listaManutencao = new ArrayList<ManutencaoVeiculo>();

	public List<ManutencaoVeiculo> getListaManutencao() {
		return listaManutencao;
	}
	public void setListaManutencaos(List<ManutencaoVeiculo> listaManutencao) {
		this.listaManutencao = listaManutencao;
	}
	public long getId() {
		return id;
	}
	public String getPlaca() {
		return placa;
	}
	public String getModelo() {
		return modelo;
	}
	public int getAno() {
		return ano;
	}
	public double getCargaMaximaPermitida() {
		return cargaMaximaPermitida;
	}
	public double getKilometros() {
		return kilometros;
	}
	public double getNivelCombustivel() {
		return nivelCombustivel;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public void setCargaMaximaPermitida(double cargaMaximaPermitida) {
		this.cargaMaximaPermitida = cargaMaximaPermitida;
	}
	public void setKilometros(double kilometros) {
		this.kilometros = kilometros;
	}
	public void setNivelCombustivel(double nivelCombustivel) {
		this.nivelCombustivel = nivelCombustivel;
	}
	public String getCor() {
		return cor;
	}
	public int getEixos() {
		return eixos;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public void setEixos(int eixos) {
		this.eixos = eixos;
	}
	
}
