INSERT INTO cliente(nome, telefone, cpf) values('luan', 34184409, 123456);
